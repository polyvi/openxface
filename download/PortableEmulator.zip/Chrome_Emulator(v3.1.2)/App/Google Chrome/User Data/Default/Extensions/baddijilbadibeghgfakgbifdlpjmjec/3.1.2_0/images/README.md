# License

The assets in this directory are excluded from the Apache Software License v.2.0.  Please see the [NOTICE](/blackberry/Ripple-UI/tree/master/ext/assets/images/NOTICE) file for more details.

